
/*
 * created 18.07.2019
 */
import java.util.*;

/**
 * @author ma5761
 *
 */
/**
 * @author ma5761
 *
 */
public class Simulation {

  private EingabeDialog eingabedialog;
  private Generation    generation;
  private Grafikfenster grafikfenster;
  private List<Zelle>   zellenModel;
  private List<Zelle>   altesZellenmodel;
  private int           verzeit;
  private int           generationzahl=0,maxalter=0,maxalterak=0,alter=0,alter2=0;

  boolean               amlaufen = false;


  /**
   * @param ed
   */
  public Simulation(EingabeDialog ed) {
    eingabedialog = ed;
  }
  public Simulation(Grafikfenster gf) {
    grafikfenster = gf;
  }

  /**
   * @param ge
   * @param ver
   */
  public Simulation(Generation ge, int ver, Grafikfenster gf, EingabeDialog ed) {
    grafikfenster = gf;
    eingabedialog= ed;
    zellenModel = new ArrayList<>();
    Zelle.resetZellenanzahl();
    verzeit = ver;
    generation = ge;
    generation.update(this);
    ZellenZeichnen(gf,ed);
  }

  public void start() {
    amlaufen = true;
    Animation();

  }

  public void stoppen() {
    amlaufen = false;

  }

  public void ZellenZeichnen(Grafikfenster gra, EingabeDialog ed) {
    grafikfenster = gra;
    eingabedialog = ed;
    int breite = grafikfenster.getBreite();
    int hoehe = grafikfenster.getHoehe();
    int zellenanzahl = breite * hoehe;
    for (int i = 0; i < zellenanzahl; i++) {
      for (int h = 0; h < hoehe; h++) {
        for (int b = 0; b < breite; b++) {
          Zelle xx = new Zelle(hoehe, breite);
          if (eingabedialog.getZufallboolean() == true) {
            if (Math.random() * 1000 < eingabedialog.getZufall()) {
              xx.ZelleTod();
              zellenModel.add(xx);
              xx.paintComponent(grafikfenster);
            } else
              zellenModel.add(xx);
              xx.paintComponent(grafikfenster);
          } else {
            xx.ZelleTod();
            zellenModel.add(xx);
            xx.paintComponent(grafikfenster);
          }
        }
      }
    }
  }

  public List<Zelle> getZelleList() {
    return zellenModel;
  }

  public static int[] InttoArray(int a) {
    int zahl = a;
    String buf = Integer.toString(zahl);
    int[] array = new int[buf.length()];
    for (int i = 0; i < buf.length(); i++) {
      array[i] = Character.getNumericValue(buf.charAt(i));
    }
    return array;
  }

  public void Step() {
    int ueber = eingabedialog.getUeberleb();
    int geburt = eingabedialog.getGeburt();
    int sterbed = eingabedialog.getSterbe();
    
    boolean gealtert = false;
    altesZellenmodel = zellenModel;

    int zahl = ueber;
    String buf = Integer.toString(zahl);
    int[] uebera = new int[buf.length()];
    for (int i = 0; i < buf.length(); i++) {
      uebera[i] = Character.getNumericValue(buf.charAt(i));
    }
    int zahl2 = geburt;
    String buf2 = Integer.toString(zahl2);
    int[] geburta = new int[buf2.length()];
    for (int j = 0; j < buf2.length(); j++) {
      geburta[j] = Character.getNumericValue(buf2.charAt(j));
    }

    for (Zelle element : altesZellenmodel) {
      for (Zelle element2 : zellenModel) {
        if (element.equals(element2)) {

          int nach = element.getlebendNachbar();
          if (element.getAlter() >= 0) {
            for (int i = 0; i < uebera.length; i++) {
              if (uebera[i] == nach) {
                element2.ZelleAltern();
                gealtert = true;
              } else {
                if (gealtert == false) {
                  element2.ZelleSterbend(sterbed);
                }
              }
            }
          } else {
            if (element.getAlter() < 0) {
              for (int i = 0; i < geburta.length; i++) {
                if (geburta[i] == nach) {
                  element2.ZelleGeburt();
                }
              }
            }
          }
        }
      }
    }
    generationzahl++;
    for(Zelle element : zellenModel) {
       alter =element.getAlter(); 
      if(alter>0) {
        if(alter>alter2) {
          maxalterak=alter;
          maxalter=alter;
          alter2=alter;
        }else alter2=alter;
      } else maxalterak=0;
    }
    generation.setNummerT(generationzahl);
    generation.setMaxalterT(maxalter);
    generation.setNowalterT(maxalterak);
    zellenModel = altesZellenmodel;
  }
public void Animation() {
  while(amlaufen==true)
    Step();
  try {
    Thread.sleep(verzeit);
  } catch (InterruptedException e) {
    e.printStackTrace();
    Thread.currentThread().interrupt();
  }
}
}
