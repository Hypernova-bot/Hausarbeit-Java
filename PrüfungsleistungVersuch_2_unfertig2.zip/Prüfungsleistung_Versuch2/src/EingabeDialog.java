import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
/*
 * created 15.07.2019
 */

/**
 * @author ma5761
 *
 */
public class EingabeDialog extends JFrame
    implements ActionListener, ChangeListener, ItemListener, FocusListener {
  private JLabel     breiteL, hoeheL, verzzeitL, ueberlebregelL, geburtregelL,
      sterbedauerL, zufallsbL, umbruchL, leer1, leer2, leer3,
      leer4, leer5, leer6;
  private JSlider    breiteS, hoeheS, verzzeitS, zufallsbS;
  private JTextField breiteT, hoeheT, verzzeitT, zufallsbT, ueberlebregelT,
      geburtregelT, sterbedauerT;
  private JButton    anfangen;
  private JCheckBox  umbruchCJa, zufallsbC;
  private int        breite, hoehe, verzzeit, ueberleb, geburt, sterbe, zufall;
  private boolean    umbruch=false,zufallboolean=false;
  private final int  MAXBREITE = 800;
  private final int  MINBREITE = 1;
  private final int  MAXHOEHE  = 300;
  private final int  MINHOEHE  = 1;
  private final int  MAXVERZ   = 1000;
  private final int  MINVERZ   = 10;
  private final int  MAXZUFALL = 1000;
  private final int  MINZUFALL = 0;
  private GrafikController controller;
  private Generation generation;
  private Simulation simulation;
  private Zelle zelle;


  /**
   * 
   */
  public EingabeDialog() {
    super("Parameter Eingabe");
    setLayout(new GridLayout(10, 3, 5, 5));
    this.setMinimumSize(new Dimension(620,250));;
    breiteL = new JLabel("Anzahl Zellen in Breite");
    breiteS = new JSlider(MINBREITE, MAXBREITE, 50);
    breite = breiteS.getValue();
    breiteS.addChangeListener(this);
    breiteT = new JTextField(Integer.toString(breite));
    breiteT.addFocusListener(this);

    hoeheL = new JLabel("Anzahl Zellen in H�he");
    hoeheS = new JSlider(MINHOEHE, MAXHOEHE, 30);
    hoehe = hoeheS.getValue();
    hoeheS.addChangeListener(this);
    hoeheT = new JTextField(Integer.toString(hoehe));
    hoeheT.addFocusListener(this);

    verzzeitL = new JLabel("Verz�gerungszeit in Millisekunden");
    verzzeitS = new JSlider(MINVERZ, MAXVERZ, 100);
    verzzeit = verzzeitS.getValue();
    verzzeitS.addChangeListener(this);
    verzzeitT = new JTextField(Integer.toString(verzzeit));
    verzzeitT.addFocusListener(this);

    ueberlebregelL = new JLabel("�berlebensregel");
    ueberlebregelT = new JTextField(Integer.toString(ueberleb));
    leer1 = new JLabel("");

    geburtregelL = new JLabel("Geburtsregel");
    geburtregelT = new JTextField(Integer.toString(geburt));
    leer2 = new JLabel("");

    sterbedauerL = new JLabel("Sterbedauer");
    sterbedauerT = new JTextField(Integer.toString(sterbe));
    leer3 = new JLabel("");

    umbruchL = new JLabel("Umbruch am Rand Aktivieren");
    umbruchCJa = new JCheckBox("Ja");
    umbruchCJa.addItemListener(this);
    leer4 = new JLabel("");

    leer5 = new JLabel("");
    zufallsbC = new JCheckBox("Zufallsbelegung aktivieren");
    zufallsbC.addItemListener(this);
    leer6 = new JLabel("");

    zufallsbL = new JLabel("Zufallsbelegung");
    zufallsbS = new JSlider(MINZUFALL, MAXZUFALL, 100);
    zufall = zufallsbS.getValue();
    zufallsbS.addChangeListener(this);
    zufallsbT = new JTextField(Integer.toString(zufall));
    zufallsbT.addFocusListener(this);
    zufallsbL.setEnabled(false);
    zufallsbS.setEnabled(false);
    zufallsbT.setEnabled(false);

    anfangen = new JButton("Anfangen");
    anfangen.addActionListener(this);

    add(breiteL);
    add(breiteS);
    add(breiteT);
    add(hoeheL);
    add(hoeheS);
    add(hoeheT);
    add(verzzeitL);
    add(verzzeitS);
    add(verzzeitT);
    add(ueberlebregelL);
    add(ueberlebregelT);
    add(leer1);
    add(geburtregelL);
    add(geburtregelT);
    add(leer2);
    add(sterbedauerL);
    add(sterbedauerT);
    add(leer3);
    add(umbruchL);
    add(umbruchCJa);
    add(leer4);
    add(leer5);
    add(zufallsbC);
    add(leer6);
    add(zufallsbL);
    add(zufallsbS);
    add(zufallsbT);
    add(anfangen);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setVisible(true);
  }

  @Override
  public void itemStateChanged(ItemEvent e) {
   if(e.getSource()==zufallsbC) {
   
     if (zufallsbL.isEnabled()) {
      zufallboolean = true;
      zufallsbL.setEnabled(false);
      zufallsbS.setEnabled(false);
      zufallsbT.setEnabled(false);
    } else {
      zufallsbL.setEnabled(true);
      zufallsbS.setEnabled(true);
      zufallsbT.setEnabled(true);
    }
   }
   if(e.getSource()==umbruchCJa) {
    if (umbruchCJa.isEnabled()) {
      umbruch = true;
    } else {
      umbruch = false;
    }
   }
  }

  @Override
  public void stateChanged(ChangeEvent e) {
    if (e.getSource() == breiteS) {
      breite = breiteS.getValue();
      breiteT.setText(Integer.toString(breite));
    } else if (e.getSource() == hoeheS) {
      hoehe = hoeheS.getValue();
      hoeheT.setText(Integer.toString(hoehe));
    } else if (e.getSource() == verzzeitS) {
      verzzeit = verzzeitS.getValue();
      verzzeitT.setText(Integer.toString(verzzeit));
    } else if (e.getSource() == zufallsbS) {
      zufall = zufallsbS.getValue();
      zufallsbT.setText(Integer.toString(zufall));
    }
  }

  @Override
  public void focusGained(FocusEvent e) {

  }

  @Override
  public void focusLost(FocusEvent e) {
    if (e.getSource() == breiteT) {
      breite = Integer.parseInt(breiteT.getText());
      if (breite < MINBREITE) {
        breite = MINBREITE;
        breiteT.setText(Integer.toString(breite));
      } else if (breite > MAXBREITE) {
        breite = MAXBREITE;
        breiteT.setText(Integer.toString(breite));
      }
      breiteS.setValue(breite);
    } else if (e.getSource() == hoeheT) {
      hoehe = Integer.parseInt(hoeheT.getText());
      if (hoehe < MINHOEHE) {
        hoehe = MINHOEHE;
        hoeheT.setText(Integer.toString(hoehe));
      } else if (hoehe > MAXHOEHE) {
        hoehe = MAXHOEHE;
        hoeheT.setText(Integer.toString(hoehe));
      }
      hoeheS.setValue(hoehe);
    } else if (e.getSource() == verzzeitT) {
      verzzeit = Integer.parseInt(verzzeitT.getText());
      if (verzzeit < MINVERZ) {
        verzzeit = MINVERZ;
        verzzeitT.setText(Integer.toString(verzzeit));
      } else if (verzzeit > MAXVERZ) {
        verzzeit = MAXVERZ;
        verzzeitT.setText(Integer.toString(verzzeit));
      }
      verzzeitS.setValue(verzzeit);
    } else if (e.getSource() == zufallsbT) {
      zufall = Integer.parseInt(zufallsbT.getText());
      if (zufall < MINZUFALL) {
        zufall = MINZUFALL;
        zufallsbT.setText(Integer.toString(zufall));
      } else if (zufall > MAXZUFALL) {
        zufall = MAXZUFALL;
        zufallsbT.setText(Integer.toString(zufall));
      }
      zufallsbS.setValue(zufall);
    }
  }
  
  @Override
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("Anfangen")) {
      setVisible(false);
      simulation = new Simulation(this);
      controller = new GrafikController(this,simulation);
      generation = new Generation(controller,simulation,this,breite,hoehe);
      zelle = new Zelle(this,simulation);

//      generation.nachStart();
      
   
    }
  }
  public boolean getUmbruch() {
    return umbruch;
  }
  public boolean getZufallboolean() {
    return zufallboolean;
  }
  public int getZufall() {
    return zufall;
  }
  public int getBreite() {
    return breite;
  }
  public int getHoehe() {
    return hoehe;
  }
  public int getUeberleb() {
    return ueberleb;
  }
  public int getGeburt() {
    return geburt;
  }
  public int getSterbe() {
    return sterbe;
  }
  public int getVerzzeit() {
    return verzzeit;
  }
  /**
   * @param args
   */
  public static void main(String[] args) {
    new EingabeDialog();
  }


}
