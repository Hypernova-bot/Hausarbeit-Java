import java.awt.*;
import java.util.List;
import javax.swing.*;

/**
 * @author ma5761
 *
 */
public class Zelle extends JPanel{
  private Graphics Graphics;
  private Grafikfenster         grafikfenster;
  private EingabeDialog         eingabedialog;
  private Simulation            simulation;
  static private int            zellenanzahl = 0;
  private int                   zellennummer;
  private int                   zeile;
  private int                   spalte;
  private Color                 color;
  private int                   alter;
  private int                   timer;
  private int                   sterbetimer;
  private List<Zelle>           zellenModel2;

  public Zelle(EingabeDialog ed, Simulation si) {
    eingabedialog = ed;
    simulation = si;
  }

  public Zelle(Grafikfenster gr) {
    grafikfenster = gr;
  }

  public Zelle(int ze, int sp) {
    zellennummer = zellenanzahl;
    zellenanzahl++;
    zeile = ze;
    spalte = sp;
    color = new Color(255, 0, 0);
    alter = 0;
    sterbetimer = 0;

  }

  public void ZelleAltern() {
    alter++;
    int b = color.getBlue();
    int r = color.getRed();
    int g = color.getGreen();
    if (b < 255) {
      b++;
    }
    if (r > 0) {
      r--;
    }
    color = new Color(r, g, b);
  }

  public void ZelleTod() {
    alter = -1;
    color = new Color(255, 255, 255);
  }
  public void ZelleGeburt() {
    alter = 0;
    color = new Color(255, 0, 0);
    sterbetimer = 0;
  }

  public void ZelleSterbend(int ti) {
    timer = ti;
    sterbetimer++;
    if (sterbetimer < timer) {
      this.ZelleAltern();
    } else {
      this.ZelleTod();
    }
  }
  public int getZeile() {
    return zeile;
  }
  public int getSpalte() {
    return spalte;
  }
  public int getAlter() {
    return alter;
  }
  public Color getColor() {
    return color;
  }
  public static void resetZellenanzahl() {
    zellenanzahl = 0;
  }
private void paintComponent(Graphics g, Grafikfenster gr) { 
    grafikfenster = gr;
    int rechteckbreite = grafikfenster.getRechteckbreite();
    int rechteckhoehe = grafikfenster.getRechteckhoehe();
    int x = getSpalte() * rechteckbreite;
    int y = getZeile() * rechteckhoehe;
    g.fillRect(x, y, rechteckbreite, rechteckhoehe);
  }
public void paintComponent(Grafikfenster gr) {
  super.paintComponent(null);  
  paintComponent(Graphics, gr);
  }

  public int getlebendNachbar() {
    boolean umbruch = eingabedialog.getUmbruch();
    zellenModel2 = simulation.getZelleList();
    int nachbar = 0, li = 0, re = 0, ob = 0, un = 0;
    int s = getSpalte();
    int z = getZeile();
    if (s == 0) {
      if (umbruch == false) {
        li = 0;
      } else {
        s += grafikfenster.getBreite();
        for (Zelle ze : zellenModel2) {
          if (ze.getSpalte() == s && ze.getZeile() == z) {
            int alter = ze.getAlter();
            if (alter >= 0)
              li = 1;
          }
        }
      }

    } else {
      s -= 1;
      for (Zelle ze : zellenModel2) {
        if (ze.getSpalte() == s && ze.getZeile() == z) {
          int alter = ze.getAlter();
          if (alter >= 0)
            li = 1;
        }
      }
    }
    if (s == grafikfenster.getBreite()) {
      if (umbruch == false) {
        re = 0;
      } else {
        s -= grafikfenster.getBreite();
        for (Zelle ze : zellenModel2) {
          if (ze.getSpalte() == s && ze.getZeile() == z) {
            int alter = ze.getAlter();
            if (alter >= 0)
              re = 1;
          }
        }
      }

    } else {
      s += 1;
      for (Zelle ze : zellenModel2) {
        if (ze.getSpalte() == s && ze.getZeile() == z) {
          int alter = ze.getAlter();
          if (alter >= 0)
            re = 1;
        }
      }
    }
    if (z == 0) {
      if (umbruch == false) {
        ob = 0;
      } else {
        z += grafikfenster.getHoehe();
        for (Zelle ze : zellenModel2) {
          if (ze.getSpalte() == s && ze.getZeile() == z) {
            int alter = ze.getAlter();
            if (alter >= 0)
              ob = 1;
          }
        }
      }

    } else {
      z -= 1;
      for (Zelle ze : zellenModel2) {
        if (ze.getSpalte() == s && ze.getZeile() == z) {
          int alter = ze.getAlter();
          if (alter >= 0)
            ob = 1;
        }
      }
    }
    if (z == grafikfenster.getHoehe()) {
      if (umbruch == false) {
        un = 0;
      } else {
        z -= grafikfenster.getBreite();
        for (Zelle ze : zellenModel2) {
          if (ze.getSpalte() == s && ze.getZeile() == z) {
            int alter = ze.getAlter();
            if (alter >= 0)
              un = 1;
          }
        }
      }

    } else {
      z += 1;
      for (Zelle ze : zellenModel2) {
        if (ze.getSpalte() == s && ze.getZeile() == z) {
          int alter = ze.getAlter();
          if (alter >= 0)
            un = 1;
        }
      }
    }
    nachbar = li + re + ob + un;
    return nachbar;
  }

}
