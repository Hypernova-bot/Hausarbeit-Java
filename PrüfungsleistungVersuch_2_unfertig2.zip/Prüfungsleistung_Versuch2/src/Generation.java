import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * @author ma5761
 *
 */
public class Generation extends JFrame implements WindowListener{
  private JButton startB,schrittB,endeB;
  private JTextField nummerT,maxalterT,nowalterT;
  private Grafikfenster grafikfenster;
  private GrafikController grafikcontroller;
  private Simulation simulation;
  private EingabeDialog eingabedialog;
  private int nummer,maxalter,nowalter;


  public Generation(Simulation si) {
    simulation = si;
  }
  public Generation(EingabeDialog ed) {
    eingabedialog = ed;
  }
  /**
   * 
   */
  public Generation(GrafikController controller,Simulation simula,EingabeDialog ed,  int b, int h) {
    super("Generation");
    grafikcontroller = controller;
    simulation = simula;
    eingabedialog =ed;
    setLayout(new FlowLayout());
    this.setSize(1020,530);
    
    startB = new JButton("Start");
    schrittB = new JButton("Schritt");
    endeB = new JButton("Ende");
    nummerT = new JTextField(Integer.toString(nummer));
    maxalterT = new JTextField(Integer.toString(maxalter));
    nowalterT = new JTextField(Integer.toString(nowalter));
    
    grafikfenster = new Grafikfenster(h,b,grafikcontroller);
    add(grafikfenster);
    JPanel panel1 = new JPanel();
    panel1.setLayout(new GridLayout(6,1));
    panel1.add(startB);
    panel1.add(schrittB);
    panel1.add(endeB);
    panel1.add(nummerT);
    nummerT.setEditable(false);
    panel1.add(maxalterT);
    maxalterT.setEditable(false);
    panel1.add(nowalterT);
    nowalterT.setEditable(false);
    
    startB.addActionListener(controller);
    schrittB.addActionListener(controller);
    endeB.addActionListener(controller);
    add(panel1);
    this.addWindowListener(controller);
    pack();
    setResizable(false);
    setVisible(true);
    simulation = new Simulation(this,eingabedialog.getVerzzeit(),grafikfenster,eingabedialog);
    
  }

 /**
   * @param ed
   */

public void nachStart() {
   startB.setText("Stop");
   schrittB.setEnabled(false);  
 }
 
 public void nachStop() {
   startB.setText("Start");
   schrittB.setEnabled(true);
 }
 
 public void close() {
   dispose();
 }
 public void update(Simulation s) {
   grafikfenster.update(s);
   repaint();
 }
 
 public void setNummerT(int a) {
   nummerT.setText(Integer.toString(a));
 }
 public void setMaxalterT(int a) {
   maxalterT.setText(Integer.toString(a));
 }
 public void setNowalterT(int a) {
   nowalterT.setText(Integer.toString(a));
 }


@Override
public void windowOpened(WindowEvent e) {

}

@Override
public void windowClosing(WindowEvent e) {

}

@Override
public void windowClosed(WindowEvent e) {

}

@Override
public void windowIconified(WindowEvent e) {
}
@Override
public void windowDeiconified(WindowEvent e) {
}
@Override
public void windowActivated(WindowEvent e) {
}
@Override
public void windowDeactivated(WindowEvent e) {
}
}
