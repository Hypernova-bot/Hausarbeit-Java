import java.awt.*;
import java.awt.event.*;
import java.util.List;

/*
 * created 17.07.2019
 */

/**
 * @author ma5761
 *
 */
public class GrafikController extends WindowAdapter
    implements ActionListener, MouseListener {

  private Grafikfenster grafikfenster;
  private EingabeDialog eingabedialog;
  private Generation    generation;
  private Simulation    simulation;
  int                   im = 0;
  private List<Point>   Punkte;

  /**
   * 
   */
  public GrafikController(EingabeDialog dlg, Simulation si) {
    eingabedialog = dlg;
    simulation = si;
  }

  @Override
  public void windowClosing(WindowEvent e) {
    if (e.getSource() == generation) {
      simulation.stoppen();
    } else {
      generation.setVisible(false);
      eingabedialog.setVisible(true);
    }
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("Start")) {
      simulation.start();
      generation.nachStart();
    } else if (e.getActionCommand().equals("Stop")) {
      simulation.stoppen();
      generation.nachStop();
    } else if (e.getActionCommand().equals("Ende")) {
      
    }
  }

  @Override
  public void mouseClicked(MouseEvent e) {
    if (simulation.amlaufen == false) {
      Point maus = e.getPoint();
      int z = (int) (maus.getY() / grafikfenster.getRechteckbreite());
      int s = (int) (maus.getX() / grafikfenster.getRechteckhoehe());
      List<Zelle> zellenModel = simulation.getZelleList();
      for (Zelle ze : zellenModel) {
        if (ze.getSpalte() == s && ze.getZeile() == z) {
          ze = new Zelle(z, s);
//          zellenModel.add(ze);
        }
      }
    }
  }

  @Override
  public void mousePressed(MouseEvent e) {
    if (simulation.amlaufen == false) {
      Point maus = e.getPoint();
      Punkte.add(maus);
    }
  }

  @Override
  public void mouseReleased(MouseEvent e) {
    if (simulation.amlaufen == false) {
      for (Point element : Punkte) {
        int z = (int) (element.getY() / grafikfenster.getRechteckbreite());
        int s = (int) (element.getX() / grafikfenster.getRechteckhoehe());
        List<Zelle> zellenModel = simulation.getZelleList();
        for (Zelle ze : zellenModel) {
          if (ze.getSpalte() == s && ze.getZeile() == z) {
            ze = new Zelle(z, s);
//            zellenModel.add(ze);
          }
        }
      }
    }
  }

  @Override
  public void mouseEntered(MouseEvent e) {
  }

  @Override
  public void mouseExited(MouseEvent e) {
  }

}
