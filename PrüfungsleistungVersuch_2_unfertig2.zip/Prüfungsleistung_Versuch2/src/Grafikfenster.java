import java.awt.*;
import javax.swing.*;

/**
 * @author ma5761
 *
 */
public class Grafikfenster extends JPanel {

  private final int BREITE = 800;
  private final int HOEHE = 300;
  private int breite,hoehe;
  private int rechteckbreite,rechteckhoehe,x,y;
  private Simulation simulationModel;
  private Zelle  zelle;
  /**
   * 
   */

  public Grafikfenster(int h, int b, GrafikController lc) {
    hoehe=h;
    breite=b;
    this.addMouseListener(lc);
    rechteckbreite = BREITE/breite;
    rechteckhoehe = HOEHE/hoehe;    
    setPreferredSize(new Dimension(BREITE,HOEHE));
    zelle = new Zelle(this);
  }
  
 
public int getRechteckbreite() {
  return rechteckbreite;
}
 public int getRechteckhoehe() {
   return rechteckhoehe;
 }
 public int getHoehe() {
   return hoehe;
 }
 
 public int getBreite() {
   return breite;
 }
 public void update(Simulation s) {
   this.simulationModel = s;
   repaint();
 }
}
